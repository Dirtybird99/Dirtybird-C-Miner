#!/bin/bash
set -e
cd "$(dirname "$0")"
./dirtybird-miner-cpu "$@"
