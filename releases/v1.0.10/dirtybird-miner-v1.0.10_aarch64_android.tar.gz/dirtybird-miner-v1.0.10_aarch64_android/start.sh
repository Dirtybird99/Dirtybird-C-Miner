#!/system/bin/sh
DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$DIR:${LD_LIBRARY_PATH}"
exec "$DIR/dirtybird-miner-cpu" "$@"
